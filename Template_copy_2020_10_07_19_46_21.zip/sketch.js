var monkey , monkey_running;
var banana ,bananaImage, obstacle, obstacleImage;
var FoodGroup, obstacleGroup
var ground, invisibleGround;
var score;
var score1;

function preload(){
  
  
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  
  bananaImage = loadImage("banana.png");
  obstacleImage = loadImage("obstacle.png");
 
}



function setup() {
  createCanvas(600,200);
  
  monkey = createSprite(50,150,30,30);
  monkey.addAnimation("moving",monkey_running);
  monkey.scale = 0.1;
        
  
  ground = createSprite(300,180,600,10);
  
  invisibleGround = createSprite(200,190,600,10);
  invisibleGround.visible = false;
  
  score = 0;
  
  score1 = 0;
  
  obstacleGroup = new Group();
  foodGroup = new Group();
  
  
  monkey.setCollider("rectangle",0,0,monkey.width,monkey.height);
  monkey.debug = true

  
}


function draw() {
  
  background(180);
  
  text("Survival Time: "+ score, 500,50);
  text("Score :"+score1,50,50);
  
  
  monkey.collide(invisibleGround);
  
  score = score + Math.round(getFrameRate()/60);
  
  if(keyDown("space")) {
        monkey.velocityY = -7; 
    }
  
  monkey.velocityY = monkey.velocityY + 0.8
  
  if(monkey.isTouching(obstacleGroup)){
    obstacle.lifetime = -1;
    banana.lifetime = -1;
    obstacle.velocityX = 0;
    banana.velocityX =  0;
    monkey.velocityY = 0;
  }
  
  if(monkey.isTouching(foodGroup)){
    foodGroup.destroyEach();
    score1 = +3;
  }
  
  spawnObstacles();
  
  drawSprites();
    
  
}

function spawnObstacles(){
  if (frameCount % 100 === 0){
    obstacle = createSprite(600,160,40,10);
    banana = createSprite(600,100,40,10);
    obstacle.scale = 0.1;
    obstacle.velocityX = -7
    banana.velocityX = obstacle.velocityX
    banana.scale = 0.1
    obstacle.addImage(obstacleImage);
    banana.addImage(bananaImage);
    obstacle.lifetime = 600;
    banana.lifetime = 600;
    obstacleGroup.add(obstacle);
    foodGroup.add(banana);
  }
}






